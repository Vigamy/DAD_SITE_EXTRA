// funcao menu
function menu() {
  const escolha = window.prompt(`
    Bem vindo ao 🍿CineTech🍿. Escolha uma das opções abaixo:
    [1] - Comprar ingresso - R$ 35,00;
    [2] - Comprar refrigerante - R$ 12,00;
    [3] - Comprar pipoca - R$ 15,00;
    [4] - Finalizar compra;
    `);

  if (escolha == 1) {
    assento();
    setTimeout(() => {
      menu();
    }, 500);
  } else if (escolha == 2) {
    refri();
    setTimeout(() => {
      menu();
    }, 500);
  } else if (escolha == 3) {
    pipoca();
    setTimeout(() => {
      menu();
    }, 500);
  } else if (escolha == 4) {
    finalizar();
    setTimeout(() => {
      menu();
    }, 500);
  }
}

// descomentar para realizar a chamada da funcao
// setTimeout(() => {
//   menu();
// }, 500);
